<?php $__env->startSection('title','Loan | Edit'); ?>

<?php $__env->startSection('content'); ?>



<section class="content">

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Edit Loan Application</h4>
                </div>
                <form action="<?php echo e(Route('loan.update',$item->loan_id)); ?>" method="post">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>
                    <div class="modal-body">

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="">Borrower</label>
                                <select name="borrower_id" class="form-control">
                                    <option value=""> Select borrower </option>
                                    <?php $__currentLoopData = $borrower; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrower_edit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->borrower_id ==
                                    $borrower_edit->borrower_id): ?>
                                    <option value="<?php echo e($borrower_edit->borrower_id); ?>" selected>
                                        <?php echo e($borrower_edit->borrower_name); ?>

                                    </option>
                                    <?php else: ?>
                                    <option value="<?php echo e($borrower_edit->borrower_id); ?>">
                                        <?php echo e($borrower_edit->borrower_name); ?> </option>
                                    <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('borrower_id')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('borrower_id')); ?>

                                </div>
                                <?php endif; ?>
                            </div>

                            <div class="col-md-6">
                                <label for="">Loan Type</label>
                                <select id="loan_type" name="loan_type_id" class="form-control">
                                    <option value=""> Select loan type </option>
                                    <?php $__currentLoopData = $loan_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan_type_edit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loan_type_edit->loan_type_id ==
                                    $item->loan_type_id): ?>
                                    <option value="<?php echo e($loan_type_edit->loan_type_id); ?>" selected>
                                        <?php echo e($loan_type_edit->loan_type_name); ?>

                                    </option>
                                    <?php else: ?>
                                    <option value="<?php echo e($loan_type_edit->loan_type_id); ?>">
                                        <?php echo e($loan_type_edit->loan_type_name); ?> </option>
                                    <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('loan_type_id')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('loan_type_id')); ?></div>
                                <?php endif; ?>
                            </div>

                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="">Amount Applied</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">$</span>
                                    </div>
                                    <input type="text" class="form-control" name="amount_applied"
                                        placeholder="Amount Applied *" value="<?php echo e(old('amount_applied',$item->amount_applied)); ?>"/>
                                        <!--value="<?php echo e(old('amount_applied',number_format($item->amount_applied,2))); ?>"/>-->

                                </div>

                                <?php if($errors->has('amount_applied')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('amount_applied')); ?></div>
                                <?php endif; ?>
                            </div>


                            <div class="col-md-6">
                                <label for="">Credit Union</label>
                                <select name="credit_union_id" class="form-control">
                                    <option value=""> Select Credit Union </option>
                                    <?php $__currentLoopData = $credit_union; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit_union_edit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($credit_union_edit->credit_union_id ==
                                    $item->credit_union_id): ?>
                                    <option value="<?php echo e($credit_union_edit->credit_union_id); ?>" selected>
                                        <?php echo e($credit_union_edit->credit_union); ?>

                                    </option>
                                    <?php else: ?>
                                    <option value="<?php echo e($credit_union_edit->credit_union_id); ?>">
                                        <?php echo e($credit_union_edit->credit_union); ?> </option>
                                    <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('credit_union_id')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('credit_union_id')); ?></div>
                                <?php endif; ?>
                            </div>

                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="">BDO</label>
                                <input type="text" class="form-control" name="bdo" placeholder="BDO"
                                    value="<?php echo e(old('bdo',$item->bdo)); ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Octant employee</label>
                                <select name="employee" class="form-control">
                                    <option value="">Select Employee</option>
                                    <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->employee == $employees->name): ?>
                                    <option value="<?php echo e($employees->name); ?>" <?php echo e('selected'); ?>>
                                        <?php echo e($employees->name); ?>

                                    </option>
                                    <?php else: ?>
                                    <option value="<?php echo e($employees->name); ?>">
                                        <?php echo e($employees->name); ?>

                                    </option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                                <?php if($errors->has('employee')): ?>
                                <span class="form-text"><?php echo e($errors->first('employee')); ?></span>
                                <?php endif; ?>
                            </div>

                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="">Loan Amount</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">$</span>
                                    </div>
                                    <input type="text"  class="form-control" name="loan_amount"
                                        placeholder="Loan Amount" value="<?php echo e(old('loan_amount',$item->loan_amount)); ?>">
                                        <!--value="<?php echo e(old('loan_amount',number_format($item->loan_amount,2))); ?>">-->
                                </div>


                            </div>
                            <div class="col-md-6">
                                <label for="">Application Submitted Incomplete</label>
                                <input type="date" class="form-control" name="application_submitted_incomplete"
                                    placeholder="Application Submitted Incomplete"
                                    value="<?php echo e(old('application_submitted_incomplete',$item->application_submitted_incomplete)); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="">Credit Memo Issued</label>
                                <input type="date" class="form-control" name="credit_memo"
                                    placeholder="“Credit Memo Issued" value="<?php echo e(old('credit_memo',$item->credit_memo)); ?>">

                            </div>
                            <div class="col-md-6">
                                <label for="">Octant Recommendation</label>
                                <select class="form-control select2" name="octant_recommendation">
                                    <option value="TBD" <?php if($item->octant_recommendation == 'TBD'): ?>
                                        selected
                                        <?php endif; ?>>TBD</option>
                                    <option value="Approved" <?php if($item->octant_recommendation == 'Approved'): ?>
                                        selected
                                        <?php endif; ?>>Approved</option>
                                    <option value="Decline" <?php if($item->octant_recommendation == 'Decline'): ?>
                                        selected
                                        <?php endif; ?>>Decline</option>
                                    <option value="Withdrawn" <?php if($item->octant_recommendation == 'Withdrawn'): ?>
                                        selected
                                        <?php endif; ?>>Withdrawn</option>
                                </select>
                            </div>

                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="">UW Base Fee</label>
                                <input type="number" class="form-control" id="loan_type_base_fee" name="uw_base_fee" placeholder="UW Base Fee"
                                    value="<?php echo e(old('uw_base_fee',$item->uw_base_fee)); ?>">

                            </div>
                            <div class="col-md-6">
                                <label>Additional UW Fee Applied</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">$</span>
                                    </div>
                                    <input type="text" class="form-control" aria-label="Amount (to the nearest dollar)"
                                        name="uw_additional_fee_comments" placeholder="Additional UW Fee Applied"
                                        value="<?php echo e(old('uw_additional_fee_comments',$item->uw_additional_fee_comments)); ?>">
                                </div>
                            </div>

                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>CU Decision</label>
                                <select name="cu_decision" class="form-control">
                                    <option value="">Select CU Decision</option>
                                    <option value="Approved" <?php if($item->cu_decision == 'Approved'): ?>
                                        selected
                                        <?php endif; ?>>Approved</option>
                                    <option value="Decline" <?php if($item->cu_decision == 'Decline'): ?>
                                        selected
                                        <?php endif; ?>>Decline</option>
                                    <option value="Withdrawn" <?php if($item->cu_decision == 'Withdrawn'): ?>
                                        selected
                                        <?php endif; ?>>Withdrawn</option>
                                </select>
                                <?php if($errors->has('cu_decision')): ?>
                                <span class="form-text"><?php echo e($errors->first('cu_decision')); ?></span>
                                <?php endif; ?>

                            </div>
                            <div class="col-md-6">
                                <label for="">Signed Credit Memo</label>
                                <input type="date" class="form-control" name="signed_credit_memo"
                                    placeholder="Signed Credit Memo"
                                    value="<?php echo e(old('signed_credit_memo',$item->signed_credit_memo)); ?>">
                            </div>

                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="">Signed Commitment Letter</label>
                                <input type="date" class="form-control" name="signed_commitment_letter"
                                    placeholder="Signed Commitment Letter"
                                    value="<?php echo e(old('signed_commitment_letter',$item->signed_commitment_letter)); ?>">

                            </div>
                            <div class="col-md-6">
                                <label for="">Appraisal Order Date</label>
                                <input type="date" class="form-control" name="appraisal_and_env_ordered"
                                    placeholder="Appraisal Order Date "
                                    value="<?php echo e(old('appraisal_and_env_ordered',$item->appraisal_and_env_ordered)); ?>">
                            </div>

                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="">Appraisal Review Completed</label>
                                <input type="date" class="form-control" name="appraisal_and_env_complete"
                                    placeholder="Appraisal Review Completed"
                                    value="<?php echo e(old('appraisal_and_env_complete',$item->appraisal_and_env_complete)); ?>">

                            </div>
                            <div class="col-md-6">
                                <label>Octant Status</label>
                                <select name="closing_process" class="form-control">
                                    <option value="">Select Octant Status</option>
                                    <option value="Application" <?php if($item->closing_process == 'Application'): ?>
                                        selected
                                        <?php endif; ?>>Application</option>
                                    <option value="Underwriting" <?php if($item->closing_process == 'Underwriting'): ?>
                                        selected
                                        <?php endif; ?>>Underwriting</option>
                                    <option value="Closing" <?php if($item->closing_process == 'Closing'): ?>
                                        selected
                                        <?php endif; ?>>Closing</option>
                                </select>
                                <?php if($errors->has('closing_process')): ?>
                                <span class="form-text"><?php echo e($errors->first('closing_process')); ?></span>
                                <?php endif; ?>
                            </div>

                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>Application Date</label>
                                <input type="date" class="form-control" name="application_date"
                                    placeholder="Application Date"
                                    value="<?php echo e(old('application_date',$item->application_date)); ?>">
                            </div>
                            <div class="col-md-6">
                                <label>Date Closed</label>
                                <input type="date" class="form-control" name="date" placeholder="date"
                                    value="<?php echo e(old('date',$item->date)); ?>">
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label>UW Incomplete Start</label>
                                <input type="date" class="form-control" name="uw_incomplete_start"
                                    placeholder="UW Incomplete Start"
                                    value="<?php echo e(old('uw_incomplete_start',$item->uw_incomplete_start)); ?>">
                            </div>
                            <div class="col-md-6">
                                <label>UW Incomplete Finish</label>
                                <input type="date" class="form-control" name="uw_incomplete_finish" placeholder="UW Incomplete Finish"
                                    value="<?php echo e(old('uw_incomplete_finish',$item->uw_incomplete_finish)); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="">status</label>
                                <select class="form-control select2bs4" name="status">
                                    <option value=""> -- select status --</option>
                                    <option value="pending" <?php echo e($item->status == 'pending' ? 'selected' : ''); ?>>
                                        Pending</option>
                                    <option value="active" <?php echo e($item->status == 'active' ? 'selected' : ''); ?>>
                                        Active</option>
                                    <option value="archived" <?php echo e($item->status == 'archived' ? 'selected' : ''); ?>>
                                        Archived</option>
                                </select>
                                <?php if($errors->has('status')): ?>
                                <div class="text-danger"><?php echo e($errors->first('status')); ?>

                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label>Anticipated Close Date</label>
                                <input type="date" class="form-control" name="anticipated_close_date"
                                    placeholder="Anticipated Close Date" value="<?php echo e(old('anticipated_close_date',$item->anticipated_close_date)); ?>">
                            </div>
                            <div class="col-md-12">
                                <label for="">Notes</label>
                                <textarea rows="4" type="date" class="form-control" name="notes"
                                    placeholder="Add Notes"><?php echo e(old('notes',$item->notes)); ?></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-12">
                                <?php if($item->serviced_loan == 1): ?>
                                <input style="transform: scale(1.2);" checked type="checkbox" class="check"
                                    id="minimal-checkbox-1" name="serviced_loan">
                                <label class="pl-2" for="minimal-checkbox-1">Serviced Loan</label>
                                <?php else: ?>
                                <input style="transform: scale(1.2);" type="checkbox" class="check"
                                    id="minimal-checkbox-1" name="serviced_loan">
                                <label class="pl-2" for="minimal-checkbox-1">Serviced Loan</label>
                                <?php endif; ?>

                            </div>
                            <div class="col-md-12">
                                <?php if($item->settlement_fees_approved == 1): ?>
                                <input style="transform: scale(1.2);" checked type="checkbox" class="check"
                                    id="minimal-checkbox-1" name="settlement_fees_approved">
                                <label class="pl-2" for="minimal-checkbox-1">Settlement Fees Approved</label>
                                <?php else: ?>
                                <input style="transform: scale(1.2);" type="checkbox" class="check"
                                    id="minimal-checkbox-1" name="settlement_fees_approved">
                                <label class="pl-2" for="minimal-checkbox-1">Settlement Fees Approved</label>
                                <?php endif; ?>

                            </div>
                            <div class="col-md-12">
                                <?php if($item->loan_qcd == 1): ?>
                                <input style="transform: scale(1.2);" checked type="checkbox" class="check"
                                    id="minimal-checkbox-1" name="loan_qcd">
                                <label class="pl-2" for="minimal-checkbox-1">Loan QC’d</label>
                                <?php else: ?>
                                <input style="transform: scale(1.2);" type="checkbox" class="check"
                                    id="minimal-checkbox-1" name="loan_qcd">
                                <label class="pl-2" for="minimal-checkbox-1">Loan QC’d</label>
                                <?php endif; ?>

                            </div>
                            <div class="col-md-12">
                                <?php if($item->credit_qcd == 1): ?>
                                <input style="transform: scale(1.2);" checked type="checkbox" class="check"
                                    id="minimal-checkbox-1" name="credit_qcd">
                                <label class="pl-2" for="minimal-checkbox-1">Credit & Legal File QC’d</label>
                                <?php else: ?>
                                <input style="transform: scale(1.2);" type="checkbox" class="check"
                                    id="minimal-checkbox-1" name="credit_qcd">
                                <label class="pl-2" for="minimal-checkbox-1">Credit & Legal File QC’d</label>
                                <?php endif; ?>

                            </div>
                        </div>


                        <?php if($item->waived != null || $item->satisfied != null || $item->sort != null): ?>
                        <?php $__currentLoopData = $item->waived; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_waived): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-md-12" id="delete_category_div<?php echo e($item->sort[$loop->index]); ?>">
                            <div class="edit_category_div" style="background-color: #eee;padding:10px;margin-top:10px;">
                                <div class="form-group">
                                    <div style="display: flex;">
                                        <input type="text" id="sort" name="edit_sort[]" class="categ_sort form-control"
                                            value="<?php echo e($item->sort[$loop->index]); ?>"
                                            style="background-color: white;flex-basis: 50px;margin-right:5px;text-align: center;">
                                        <input type="text" class="form-control" name="edit_label[]" required=""
                                            value="<?php echo e($item->label[$loop->index]); ?>" placeholder="Enter Label"
                                            style="background-color: white;" />

                                            <button onclick="removeForm('delete_category_div<?php echo e($item->sort[$loop->index]); ?>')" type="button"
                                            class="btn btn-danger m-0 ml-2">
                                            <i class="fa fa-close"></i></button>
                                        <!--<button type="button" data-categid="1"-->
                                        <!--    class="del_category btn btn-danger m-0 ml-2">-->
                                        <!--    <i class="fa fa-close"></i></button>-->
                                        <br>


                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Waived :</label>
                                    <select name="edit_waived[]" class="form-control" style="background-color: white;">
                                        <option value=""> Select Option </option>
                                        <option value="1" <?php echo e($item->waived[$loop->index] == '1' ? 'selected' : ''); ?>>
                                            Yes
                                        </option>
                                        <option value="0" <?php echo e($item->waived[$loop->index] == '0' ? 'selected' : ''); ?>>
                                            No
                                        </option>
                                    </select>

                                </div>
                                <div class="form-group">
                                    <label>Satisfied :</label>
                                    <select name="edit_satisfied[]" class="form-control"
                                        style="background-color: white;">
                                        <option value=""> Select Option </option>
                                        <option value="1" <?php echo e($item->satisfied[$loop->index] == '1' ? 'selected' : ''); ?>>
                                            Yes</option>
                                        <option value="0" <?php echo e($item->satisfied[$loop->index] == '0' ? 'selected' : ''); ?>>
                                            No
                                        </option>
                                    </select>
                                </div>
                                <br>
                            </div>
                            <br>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" id="raw_count" value="<?php echo e(count($item["sort"])); ?>">
                        <?php endif; ?>
                        <div class="col-md-12">
                            <div class="edit_category_main">

                                <button type="button" class="edit_category btn btn-info fa fa-plus "> Add
                                    Pre Closing Condition</button>
                                <br>
                            </div>
                        </div>

                    </div>
                    <div class="card-footer text-center">
                        <button type="submit" class="btn btn-info font-weight-bold">Update Loan</button>
                    </div>
                </form>
            </div>
        </div>

</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_scripts'); ?>


<script>
    $(document).ready(function () {
        $('#loan_type').change(function(){
            if($(this).val() != ''){
                var value = $(this).val();
                var _token = $('input[name = "_token"]').val();

                $.ajax({
                    url:" <?php echo e(Route('loan.fetch.data')); ?> ",
                    method : "POST",
                    data:{
                        value:value , _token:_token ,
                    },
                    success:function(result){
                        var parsed_data = JSON.parse(result);
                        $('#loan_type_base_fee').val(parsed_data.uw_base_fee);
                        console.log(result);
                    }
                })

                // console.log(result);
            }
        });
    });
</script>


<script>
    if($('#raw_count').val() == null){
      var  raw_count = 0;
    }else{
       var raw_count = $('#raw_count').val();
    }

    console.log(raw_count);

    var edit_category = '<div class="category_div" style="background-color: #eee;padding:10px;margin-top:10px;"><div class="form-group"><div style="display: flex;"> <input type="text" name="edit_sort[]" class="categ_sort form-control" value="1" style="background-color: white;flex-basis: 50px;margin-right:5px;text-align: center;"> <input type="text" class="form-control" name="edit_label[]" placeholder="Please Enter Label" style="background-color: white;" /> <button type="button" data-categid="1" class="edit_del_category btn btn-danger m-0 ml-2"><i class="fa fa-close"></i></button> </div><br>  <div class="form-group"> <label>Waived :</label> <select name="edit_waived[]" class="form-control" style="background-color: white;">  <option value=""> Select Option </option> <option value="1">Yes</option> <option value="0">No</option> </select> </div> <div class="form-group"> <label>Satisfied :</label> <select name="edit_satisfied[]" class="form-control" style="background-color: white;"> <option value=""> Select Option </option> <option value="1">Yes</option> <option value="0">No</option> </select> </div>';

    var categs_edit= raw_count;


        $(document).on('click',".edit_category",function(){
        categs_edit++;

        $(".edit_category_main").append(edit_category.replace('value="1"','value="'+categs_edit+'"').replace('name="categ_1_product_name[]"','name="categ_'+categs_edit+'_product_name[]"').replace('data-categid="1"','data-categid="'+categs_edit+'"'));

        });
        $(document).on('click',".edit_del_category",function(){
        if(categs_edit>raw_count){
        var categ_id = $(this).attr('data-categid');
        $(this).parent().parent().parent().remove();
        // alert(parseInt(categ_id));
        for (var i = parseInt(categ_id); i <= $(".categ_sort").length; i++) { $(".categ_sort").eq(i-1).val(i);
            $("button[data-categid='"+(i+1)+"' ]").attr('data-categid',i); $("input[name='categ_"+(i+1)+"_product_name[]' ]").attr('name',"categ_"+i+"_product_name[]"); $("input[name='categ_"+(i+1)+"_subitem_id[]' ]").attr('name',"categ_"+i+"_subitem_id[]");
        }
    }
    categs_edit--;
});

function removeForm(id){
            console.log(id);
            $("#"+id).remove();
            categs_edit--;
        }

</script>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\octant\resources\views/admin/loan/edit.blade.php ENDPATH**/ ?>